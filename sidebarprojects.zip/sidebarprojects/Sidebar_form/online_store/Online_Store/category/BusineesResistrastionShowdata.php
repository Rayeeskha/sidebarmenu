<?php include '../db/config.php'; ?>
<?php error_reporting(E_ALL);
ini_set('display_errors',true);

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.12.0/css/mdb.min.css" rel="stylesheet">
</head>
<body>
	
		<div id="content" class="p-4 p-md-5 pt-5">
   <div class="card ">
       
  
    
      
      <h1 class="text-center">Registered Customer</h1>
      <li><a href="../Menu.php" class="btn btn-info">Back to Home Page</a></li>
      <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 table-responsive">

        <table class="table table-border table-striped table-hover  text-center">


        

        	
          <thead>
           
            <th>Name</th>
            <th>Profile Pics</th>
            
            <th>Business Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            
            <th>Website URL</th>
            <th>Products</th>
            
            <th>Sub Categtory</th>
            <th>Description</th>
          </thead>
          <tbody>
            <?php

              $query = "SELECT  * FROM   business_account_form ";

              $querydisplay = mysqli_query($connection, $query);

              while ($result = mysqli_fetch_array($querydisplay)) {
                # code...
                ?>
                <tr>
                  
                  <td><?php echo $result['NAME'] ?></td>
                  <td><img src="<?php echo $result['IMAGE']; ?>" height="100px" width="100px"></td>
                  
                  <td><?php echo $result['BUSINESS_NAME'] ?></td>
                  <td><a class="btn btn-whatsapp btn btn-success text-white" type="button" role="button" class="btn btn-info"><i class="fab fa-whatsapp pr-1"></i><?php echo $result['PHONE_NUMBER'] ?></a></td>
                  <td><?php echo $result['EMAIL'] ?></td>
                  
                  <td><?php echo $result['WEBSITE_URL'] ?></td>
                  <td><?php echo $result['PRODUCTS'] ?></td>
                  
                  <td><?php echo $result['SUB_CATEGORY'] ?></td>
                  <td><?php echo $result['DISCRIPTION'] ?></td>
                </tr>
                <?php
              }





             ?>
          </tbody>
      </div>
      
    </div>
  </div>
		</div>



		<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.12.0/js/mdb.min.js"></script>

</body>
</html>