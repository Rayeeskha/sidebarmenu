let categoryArray = [{id:1,name:'JD News'},{id:2,name:'Jd Social'},{id:3,name:'Anything On Hire'},
					{id:4,name:'Apply for Loans'},{id:5,name:'Auto Care'},{id:6,name:'Automobile'},{id:7,name:'B2B'},{id:8,name:'Baby Care'},
					{id:9,name:'Banquets'},{id:10,name:'Cabs & Car Rental'},{id:11,name:'Caterers'},{id:12,name:'Chemists'},{id:13,name:'Civil Contractors'},
					{id:14,name:'All Courier Services'},{id:15,name:'Daily Needs'},{id:16,name:'Dance & Music'},{id:17,name:'Doctors'},{id:18,name:'Education'},
					{id:19,name:'Emergency'},{id:20,name:'Entertainment'},{id:21,name:'Event Organizers'},{id:22,name:'Fitness'},{id:23,name:'Flights'},
					{id:24,name:'Foreign-Exchange'},{id:25,name:'Florists'},{id:26,name:'Home Decor'},{id:27,name:'Home Improvements'},{id:28,name:'Hospitals'},
					{id:29,name:'Hotels'},{id:30,name:'House Keeping'},{id:31,name:'Industrial Products'},{id:32,name:'Insurance3'},{id:33,name:'Designers For College'},
					{id:34,name:'International Sim Cards'},{id:35,name:'Internet'},{id:36,name:'Jobs'},{id:37,name:'Jewellery'},{id:38,name:'Labs'},
					{id:39,name:'Language Classes'},{id:40,name:'Medical'},{id:41,name:'Modular Kitchen'},{id:42,name:'Movies'},{id:43,name:'Home Services'},
					{id:44,name:'Packers & Movers'},{id:45,name:'Party'},{id:46,name:'Persional Care'},{id:47,name:'Pest Control'},{id:48,name:'Pet & Pet Care'},
					{id:49,name:'Play Schools'},{id:50,name:'Real Estate'},{id:51,name:'Repairs'},{id:52,name:'Restaurants'},{id:53,name:'Shop Online'},
					{id:54,name:'Security Services'},{id:55,name:'Shopping'},{id:56,name:'Sports Coach'},{id:57,name:'Sports Goods'},{id:58,name:'Train'},
					{id:59,name:'Training Institutes For SAP'},{id:60,name:'Transporters'},{id:61,name:'Travel'},{id:62,name:'Wedding'},{id:63,name:'Bills & Recharge'},
					{id:64,name:'Book HOtels'},{id:65,name:'Books'},{id:66,name:'Bus'}];


let subcategoryArray = [{sub_id:3,sub_name:'Car On Hire'},{sub_id:3,sub_name:'Customer On Hire'},
					{sub_id:3,sub_name:'Bus on Hire'},{sub_id:3,sub_name:'Tempos on Hire'},{sub_id:3,sub_name:'Mini Bus on Hire'},{sub_id:3,sub_name:'AC on Hire'},
					{sub_id:3,sub_name:'Rooms on Hire'},{sub_id:3,sub_name:'Truck  on Hire'},{sub_id:3,sub_name:'Vans  on Hire'},{sub_id:4,sub_name:'Home Loans'},
					{sub_id:4,sub_name:'Credit Card'},{sub_id:4,sub_name:'Persional Loan'},{sub_id:4,sub_name:'Business Loan'},{sub_id:4,sub_name:'Educational Loan'},
					{sub_id:4,sub_name:'Loan Against Gold'},{sub_id:5,sub_name:'car Repair'},{sub_id:5,sub_name:'car tyres'},{sub_id:5,sub_name:'car Batteries'},
					{sub_id:5,sub_name:'car Accessories'},{sub_id:5,sub_name:'Car Wash'},{sub_id:5,sub_name:'Motor Cycle Repair'},{sub_id:5,sub_name:'Scooter  Repair'},
					{sub_id:5,sub_name:'Two wheeler Tyres'},{sub_id:5,sub_name:'Two wheeler Batteries'},{sub_id:5,sub_name:'Two wheeler'},{sub_id:6,sub_name:'New Cars'},
					{sub_id:6,sub_name:'Used Cars'},{sub_id:6,sub_name:'Sell Cars'},{sub_id:6,sub_name:'Test Driver'},{sub_id:7,sub_name:'Electronics & Electrical Supplies'},
					{sub_id:7,sub_name:'Industrial Machinery & Equipments'},{sub_id:7,sub_name:'Construction Machinery & Supplies'},
					{sub_id:7,sub_name:'AutoMobile Spare Parts & Services'},{sub_id:7,sub_name:'Logestics & Transportation'},{sub_id:7,sub_name:'Industrial Supplies'},
					{sub_id:8,sub_name:'Baby Food'},{sub_id:8,sub_name:'Baby Sitters'},{sub_id:8,sub_name:'Baby Sleep'},{sub_id:8,sub_name:'Bath'},
					{sub_id:8,sub_name:'Books'},{sub_id:8,sub_name:'Clothes'},{sub_id:8,sub_name:'Creams'},{sub_id:8,sub_name:'Diapers'},{sub_id:8,sub_name:'Footware'},
					{sub_id:8,sub_name:'Grooming'},{sub_id:8,sub_name:'Safety'},{sub_id:8,sub_name:'Toys'},{sub_id:8,sub_name:'Health'},{sub_id:9,sub_name:'All Banquets Halls'},
					{sub_id:9,sub_name:'5* Star Banquet Halls'},{sub_id:9,sub_name:'AC Banquet Halls'},{sub_id:9,sub_name:'Lawn For Events'},{sub_id:9,sub_name:'Non AC Banquets Halls'},
					{sub_id:9,sub_name:'Clothes'},{sub_id:9,sub_name:'Creams'},{sub_id:9,sub_name:'Diapers'},{sub_id:9,sub_name:'Footware'},{sub_id:9,sub_name:'Grooming'},{sub_id:9,sub_name:'Safety'},
					{sub_id:9,sub_name:'Toys'},{sub_id:9,sub_name:'Health'},{sub_id:10,sub_name:'BOOK A CAB ONLINE'},{sub_id:10,sub_name:'CAR RENTALS'},{sub_id:11,sub_name:'All caterers'},
					{sub_id:11,sub_name:'Birthday Party caterers'},{sub_id:11,sub_name:'Party Caterers'},{sub_id:11,sub_name:'wedding Caterers'},{sub_id:11,sub_name:'Office caterers'},
					{sub_id:12,sub_name:'Chemists'},{sub_id:13,sub_name:'Carpentry Contractors'},{sub_id:13,sub_name:'Civil Contractors'},{sub_id:13,sub_name:'Electrical Contractors'},
					{sub_id:13,sub_name:'Flooring Contractors'},{sub_id:13,sub_name:'Furniture Contractors'},{sub_id:13,sub_name:'Painting Contractors'},{sub_id:13,sub_name:'Plumbing Contractors'},
					{sub_id:13,sub_name:'Furniture Contractors'},{sub_id:13,sub_name:'Painting Contractors'},{sub_id:13,sub_name:'Welding Contractors'},{sub_id:14,sub_name:'International'},
					{sub_id:14,sub_name:'Local'},{sub_id:14,sub_name:'National'},{sub_id:14,sub_name:'Bulk Courier'},{sub_id:15,sub_name:'Grocery'},{sub_id:15,sub_name:'Chemists'},{sub_id:15,sub_name:'Bakery'},
					{sub_id:15,sub_name:'Dairy Products'},{sub_id:15,sub_name:'Cakes'},{sub_id:15,sub_name:'Ice- Creams'},{sub_id:16,sub_name:'All Dance Classes'},{sub_id:16,sub_name:'Bollywood'},
					{sub_id:16,sub_name:'Classical Dance'},{sub_id:16,sub_name:'Hip HOP'},{sub_id:16,sub_name:'Salsa'},{sub_id:17,sub_name:'Ayurvedic Doctors'},{sub_id:17,sub_name:'Cardiologists'},
					{sub_id:17,sub_name:'Chest Specialist'},{sub_id:17,sub_name:'Cosmatic Surgeons'},{sub_id:17,sub_name:'Dentists'},{sub_id:17,sub_name:'Dermatologists'}, {sub_id:17,sub_name:'Dietitians'},
					{sub_id:17,sub_name:'ENT Specialists'},{sub_id:17,sub_name:'Gastroenterologists Specialists'},{sub_id:17,sub_name:'General Physicians'},{sub_id:17,sub_name:'Gynaecologist & Obstetricians'},
					{sub_id:17,sub_name:'Homeopathic Doctors'},{sub_id:17,sub_name:'Neurologists'},{sub_id:17,sub_name:'Neurosurgeons'},{sub_id:17,sub_name:'On Call Doctors'},{sub_id:17,sub_name:'Paeditricians'},
					{sub_id:17,sub_name:'Physiotherapists for Home Visit'},{sub_id:17,sub_name:'Physiotherapists'},{sub_id:17,sub_name:'Piles Doctors'},{sub_id:17,sub_name:'Sexologists'},
					{sub_id:17,sub_name:'Skin & Hair Doctors'},{sub_id:18,sub_name:'School'},{sub_id:18,sub_name:'Collages'},{sub_id:18,sub_name:'Acting Classes'},{sub_id:18,sub_name:'Art & Craft classes'},
					{sub_id:18,sub_name:'Coaching Classes & Tutorial'},{sub_id:18,sub_name:'Language Classes'},{sub_id:18,sub_name:'Music Classes'},{sub_id:18,sub_name:'Painting classes'},
					{sub_id:18,sub_name:'Photography Classes'},{sub_id:18,sub_name:'Soft skill & Image Building'},{sub_id:18,sub_name:'Training Institute'},{sub_id:18,sub_name:'Training Institute'},
					{sub_id:19,sub_name:'24 HOURS Chemists'},{sub_id:19,sub_name:'Ambulance Service'},{sub_id:19,sub_name:'Blood Bank'},{sub_id:19,sub_name:'Cardiologists'},{sub_id:19,sub_name:'Duplicate Key Stores'},
					{sub_id:19,sub_name:'Fire Brigade'},{sub_id:19,sub_name:'Hospitals'},{sub_id:19,sub_name:'Police'},{sub_id:19,sub_name:'Snake catchers'},{sub_id:19,sub_name:'Towing Services'},
					{sub_id:20,sub_name:'Entertainment'},{sub_id:21,sub_name:'Carporate Parties'},{sub_id:21,sub_name:'Private Partise'},{sub_id:21,sub_name:'Seminar Organizers'},{sub_id:21,sub_name:'Stage show Organizers'},
					{sub_id:21,sub_name:'Trade Fade Organizers'},{sub_id:21,sub_name:'Wedding Organizers'},{sub_id:21,sub_name:'Hospitals'},{sub_id:21,sub_name:'Police'},
					{sub_id:21,sub_name:'Snake catchers'},{sub_id:21,sub_name:'Towing Services'},{sub_id:22,sub_name:'Dietitians'},{sub_id:22,sub_name:'Fitness Classes'},{sub_id:22,sub_name:'Gym'},
					{sub_id:22,sub_name:'Health Equipments'},{sub_id:22,sub_name:'Health Food & Suppliments'},{sub_id:22,sub_name:'Meditation & Relaxation'},{sub_id:22,sub_name:'Pilates Studios'},
					{sub_id:22,sub_name:'Reformer Studies'},{sub_id:22,sub_name:'Sport Club'},{sub_id:22,sub_name:'Weight Reduction'},{sub_id:22,sub_name:'Yoga Classes'},{sub_id:23,sub_name:'Flights'},
					{sub_id:24,sub_name:'Foreign-Exchange'},{sub_id:25,sub_name:'Flower Shops'},{sub_id:25,sub_name:'Florists Home Delivery'},{sub_id:25,sub_name:'24 Hours Florists'},
					{sub_id:25,sub_name:'Florists For Wedding Decoratrion'},{sub_id:26,sub_name:'Furnitures'},{sub_id:26,sub_name:'Furnishing'},{sub_id:26,sub_name:'Lamp & Lighting'},{sub_id:26,sub_name:'Kitchen & Dine'},
					{sub_id:26,sub_name:'Bath'},{sub_id:26,sub_name:'House Keeping'},{sub_id:27,sub_name:'Architects & Engineers'},{sub_id:27,sub_name:'Carpets'},{sub_id:27,sub_name:'Flooring'},{sub_id:27,sub_name:'Insulation'},
					{sub_id:27,sub_name:'Modular Kitchens'},{sub_id:27,sub_name:'Paintings'},{sub_id:27,sub_name:'Swimming Pools'},{sub_id:27,sub_name:'Wall claddings'},{sub_id:27,sub_name:'Wall Papers'},
					{sub_id:28,sub_name:'Children Hospitals'},{sub_id:28,sub_name:'ENT Hospitals'},{sub_id:28,sub_name:'Eye Hospitals'},{sub_id:28,sub_name:'Maternity Hospitals'},{sub_id:28,sub_name:'Mental Hospitals'},
					{sub_id:28,sub_name:'Multispeciality Hospitals'},{sub_id:28,sub_name:'Private Hospitals'},{sub_id:28,sub_name:'Veterinary Hospitals'},{sub_id:29,sub_name:'Hotels'},{sub_id:30,sub_name:'Cooks'},
					{sub_id:30,sub_name:'Maids'},{sub_id:30,sub_name:'Drivers'},{sub_id:30,sub_name:'Laundary Services'},{sub_id:30,sub_name:'Cleaning Services'},{sub_id:30,sub_name:'Pest Control'},{sub_id:31,sub_name:'Industrial Parts'},
					{sub_id:31,sub_name:'Industrial Tools'},{sub_id:31,sub_name:'Industry Specific Mashine'},{sub_id:31,sub_name:'Welding Equipmets & Machines'},{sub_id:32,sub_name:'Insurance3'},{sub_id:33,sub_name:'Architects'},
					{sub_id:33,sub_name:'Residence'},{sub_id:33,sub_name:'Commercial'},{sub_id:33,sub_name:'Interior Designer Institutes'},{sub_id:34,sub_name:'International Sim Cards'},{sub_id:35,sub_name:'Internet Service Provider'},
					{sub_id:35,sub_name:'Web Designers'},{sub_id:35,sub_name:'Cyber Cafes'},{sub_id:35,sub_name:'Wifi Internet Service Providers'},{sub_id:36,sub_name:'Jobs'},{sub_id:37,sub_name:'ALL Jewellery'},
					{sub_id:37,sub_name:'Bridal Jewellery'},{sub_id:37,sub_name:'Bangles'},{sub_id:37,sub_name:'Bracelets'},{sub_id:37,sub_name:'Gold Coins'},{sub_id:37,sub_name:'Chains'},{sub_id:37,sub_name:'Earrings'},
					{sub_id:37,sub_name:'Mangalsutras'},{sub_id:37,sub_name:'Necklaces'},{sub_id:37,sub_name:'Nose Pins'},{sub_id:37,sub_name:'Pendents'},{sub_id:37,sub_name:'Rings'},{sub_id:38,sub_name:'Labs'},
					{sub_id:39,sub_name:'Arabic'},{sub_id:39,sub_name:'Chinese'},{sub_id:39,sub_name:'English'},{sub_id:39,sub_name:'French'},{sub_id:39,sub_name:'German'},{sub_id:39,sub_name:'Hindi'},{sub_id:39,sub_name:'Italian'},
					{sub_id:39,sub_name:'Japanese'},{sub_id:39,sub_name:'Russian'},{sub_id:39,sub_name:'Spanish'},{sub_id:40,sub_name:'Doctors'},{sub_id:40,sub_name:'Hopitals'},{sub_id:40,sub_name:'Dentists'},{sub_id:40,sub_name:'Chemists'},
					{sub_id:40,sub_name:'Pathology Labs'},{sub_id:40,sub_name:'Ambulance'},{sub_id:40,sub_name:'Opticians'},{sub_id:40,sub_name:'Blood Banks'},{sub_id:41,sub_name:'Cabinets'},{sub_id:41,sub_name:'Chimneys'},
					{sub_id:41,sub_name:'Gas Stoves'},{sub_id:41,sub_name:'Built in Hobs'},{sub_id:41,sub_name:'Shutters'},{sub_id:41,sub_name:'L shaped Kitchen'},{sub_id:42,sub_name:'Movies'},{sub_id:43,sub_name:'Carpenters'},
					{sub_id:43,sub_name:'Carpet Cleaners'},{sub_id:43,sub_name:'Driver Service'},{sub_id:43,sub_name:'Duplicate Key Makers'},{sub_id:43,sub_name:'Electricians'},{sub_id:43,sub_name:'Masons'},{sub_id:43,sub_name:'Painters'},
					{sub_id:43,sub_name:'Pest Controlls'},{sub_id:43,sub_name:'Plumbers'},{sub_id:43,sub_name:'Towing Services'},{sub_id:43,sub_name:'Carpet Contractors'},{sub_id:43,sub_name:'Electric Chimney'},{sub_id:43,sub_name:'Fire Fighting Contractors'},
					{sub_id:43,sub_name:'Flooring Contractors'},{sub_id:43,sub_name:'Civil Contractors'},{sub_id:43,sub_name:'Gardening Tools Services'},{sub_id:43,sub_name:'House Keeping Cleaning'},{sub_id:43,sub_name:'Interior Designers Architecture'},
					{sub_id:43,sub_name:'Interior Decorator'},{sub_id:43,sub_name:'Internet Service Providers'},{sub_id:43,sub_name:'Lock Repair Services'},{sub_id:43,sub_name:'Architects'},{sub_id:43,sub_name:'Packaging Labelling'},
					{sub_id:43,sub_name:'Swimming Contractors'},{sub_id:43,sub_name:'Painting Contractors'},{sub_id:43,sub_name:'Roofing Contractors'},{sub_id:43,sub_name:'Security Equipment Services'},{sub_id:43,sub_name:'DTH'},
					{sub_id:43,sub_name:'Wall Paper Contractors'},{sub_id:43,sub_name:'Water Proofing Contractors'},{sub_id:44,sub_name:'All Options'},{sub_id:44,sub_name:'Local'},{sub_id:44,sub_name:'National'},{sub_id:44,sub_name:'International'},
					{sub_id:44,sub_name:'Movers For Automobile'},{sub_id:45,sub_name:'Banquet Halls'},{sub_id:45,sub_name:'DJ on Hire'},{sub_id:45,sub_name:'Event Organisers'},{sub_id:45,sub_name:'Photographers'},
					{sub_id:45,sub_name:'Wine Retailers'},{sub_id:45,sub_name:'Party Organisers For Children'},{sub_id:45,sub_name:'Playback Singers'},{sub_id:46,sub_name:'Beauty Parlours'},{sub_id:46,sub_name:'Beauty Services'},
					{sub_id:46,sub_name:'Bridal Makeup'},{sub_id:46,sub_name:'Bridegroom Makeup'},{sub_id:46,sub_name:'Salons'},{sub_id:46,sub_name:'Spas'},{sub_id:47,sub_name:'Pest Control'},{sub_id:47,sub_name:'Commercial Pest Control'},
					{sub_id:47,sub_name:'Residential Pest Control'},{sub_id:47,sub_name:'Bird Control'},{sub_id:47,sub_name:'Cockroach Control'},{sub_id:47,sub_name:'Commercial Pest Control'},{sub_id:47,sub_name:'Fly Control'},
					{sub_id:48,sub_name:'Pet Accessories'},{sub_id:48,sub_name:'Pet Food'},{sub_id:48,sub_name:'Pet Shops'},{sub_id:48,sub_name:'Birds'},{sub_id:48,sub_name:'Fish'},{sub_id:48,sub_name:'Small Pets'},
					{sub_id:49,sub_name:'Kindergarten'},{sub_id:49,sub_name:'Montessori Schools'},{sub_id:49,sub_name:'Play Schools'},{sub_id:49,sub_name:'Pre-School'},{sub_id:50,sub_name:'Rent'},{sub_id:50,sub_name:'Sell'},
					{sub_id:50,sub_name:'PG, Hostels and Rooms'},{sub_id:51,sub_name:'AC'},{sub_id:51,sub_name:'Car'},{sub_id:51,sub_name:'Computer'},{sub_id:51,sub_name:'Laptop'},{sub_id:51,sub_name:'Mobile Phone'},
					{sub_id:51,sub_name:'Motorcycle'},{sub_id:51,sub_name:'Refrigerator'},{sub_id:51,sub_name:'Washing Machine'},{sub_id:51,sub_name:'Water Purifier'},{sub_id:52,sub_name:'Restaurants'},{sub_id:53,sub_name:'Shop Online'},
					{sub_id:54,sub_name:'Bodyguards'},{sub_id:54,sub_name:'CCTV Cameras'},{sub_id:54,sub_name:'Hire Detectives'},{sub_id:54,sub_name:'Lock'},{sub_id:54,sub_name:'Lock Repair & Services'},{sub_id:54,sub_name:'Security Services'},
					{sub_id:54,sub_name:'Valet Parking Services'},{sub_id:54,sub_name:'Walkie Talkie Dealers'},{sub_id:55,sub_name:'Shopping For Men'},{sub_id:55,sub_name:'Shopping For Women'},{sub_id:55,sub_name:'Shopping For Kids'},
					{sub_id:56,sub_name:'Athletics'},{sub_id:56,sub_name:'Badminton'},{sub_id:56,sub_name:'Basketball'},{sub_id:56,sub_name:'Boxing'},{sub_id:56,sub_name:'Chess'},{sub_id:56,sub_name:'Cricket'},{sub_id:56,sub_name:'Football'},
					{sub_id:56,sub_name:'Gymnastic'},{sub_id:56,sub_name:'Hockey'},{sub_id:56,sub_name:'Judo'},{sub_id:56,sub_name:'Karate'},{sub_id:56,sub_name:'Skating'},{sub_id:56,sub_name:'Squash'},{sub_id:56,sub_name:'Swimming'},
					{sub_id:56,sub_name:'Table Tennis'},{sub_id:56,sub_name:'Tennis'},{sub_id:56,sub_name:'Volleyball'},{sub_id:57,sub_name:'Basketball'},{sub_id:57,sub_name:'Billiards & Pool'},{sub_id:57,sub_name:'Cricket'},
					{sub_id:57,sub_name:'Cycling'},{sub_id:57,sub_name:'Football'},{sub_id:57,sub_name:'Golf'},{sub_id:57,sub_name:'Hiking And Camping'},{sub_id:57,sub_name:'Hockey'},{sub_id:57,sub_name:'Skating'},{sub_id:57,sub_name:'Squash'},
					{sub_id:57,sub_name:'Swimming'},{sub_id:57,sub_name:'Tennis'},{sub_id:58,sub_name:'Train'},{sub_id:59,sub_name:'Administration Training'},{sub_id:59,sub_name:'Basic Computing'},{sub_id:59,sub_name:'Computer Hardware Training'},
					{sub_id:59,sub_name:'Computer Networking Training'},{sub_id:59,sub_name:'Database Training'},{sub_id:59,sub_name:'Engineering Design Training'},{sub_id:59,sub_name:'Mobile Development Training'},
					{sub_id:59,sub_name:'Multimedia & Design Training'},{sub_id:59,sub_name:'Programming Languages'},{sub_id:59,sub_name:'Web Technology Training'},{sub_id:59,sub_name:'Web Technology Training'},
					{sub_id:60,sub_name:'Animal Transporters'},{sub_id:60,sub_name:'Antiques & Special Care Items'},{sub_id:60,sub_name:'Business & Industrial Goods'},{sub_id:60,sub_name:'Food & Agriculture Products'},
					{sub_id:60,sub_name:'Full Container Load Freight'},{sub_id:60,sub_name:'Household Goods'},{sub_id:60,sub_name:'Junk Transporters'},{sub_id:60,sub_name:'Low Container Load Freight'},{sub_id:60,sub_name:'Plants & Heavy Equipments'},
					{sub_id:60,sub_name:'Vehicles Transporters'},{sub_id:61,sub_name:'Hotels'},{sub_id:61,sub_name:'Flights'},{sub_id:61,sub_name:'Bus'},{sub_id:61,sub_name:'Car Rentals'},{sub_id:61,sub_name:'Cabs'},
					{sub_id:61,sub_name:'Trains'},{sub_id:61,sub_name:'International SIM Card'},{sub_id:61,sub_name:'Visa'},{sub_id:61,sub_name:'Foreign Exchange'},{sub_id:61,sub_name:'Meals On Train'},
					{sub_id:61,sub_name:'Tempo Travellers'},{sub_id:62,sub_name:'Banquet Halls'},{sub_id:62,sub_name:'Bridal Requisites'},{sub_id:62,sub_name:'Florists'},{sub_id:62,sub_name:'Jewellery'},{sub_id:62,sub_name:'Matrimonial Bureaus'},
					{sub_id:62,sub_name:'Photographers'},{sub_id:62,sub_name:'Wedding Cards'},{sub_id:62,sub_name:'Visa'},{sub_id:62,sub_name:'Foreign Exchange'},{sub_id:62,sub_name:'Meals On Train'},{sub_id:62,sub_name:'Tempo Travellers'},
					{sub_id:62,sub_name:'DJ On Hire'},{sub_id:62,sub_name:'Dance Groups'},{sub_id:62,sub_name:'Dhol Players'},{sub_id:62,sub_name:'Doli On Hire'},{sub_id:62,sub_name:'Event Organisers'},{sub_id:62,sub_name:'Fireworks'},
					{sub_id:62,sub_name:'Florists'},{sub_id:62,sub_name:'Flower Decorators'},{sub_id:62,sub_name:'Generator & Power Backup'},{sub_id:62,sub_name:'Guest Houses'},{sub_id:62,sub_name:'Horses On Hire'},{sub_id:62,sub_name:'Jewellery'},
					{sub_id:62,sub_name:'Juice Services'},{sub_id:62,sub_name:'Kids Entertainment'},{sub_id:62,sub_name:'Mandap Decorator'},{sub_id:62,sub_name:'Marriage Gardens'},{sub_id:62,sub_name:'Matrimonial Bureaus'},
					{sub_id:62,sub_name:'Mehendi Artists'},{sub_id:62,sub_name:'Music Bands'},{sub_id:62,sub_name:'Paan Suppliers'},{sub_id:62,sub_name:'Pandits'},{sub_id:62,sub_name:'Photographers'},{sub_id:62,sub_name:'Readymade Garment Retailer'},
					{sub_id:62,sub_name:'Sound System On Hire'},{sub_id:62,sub_name:'Sweet Shops'},{sub_id:62,sub_name:'Tent House'},{sub_id:62,sub_name:'Wedding Cards'},{sub_id:62,sub_name:'Wedding Grocery'},{sub_id:62,sub_name:'Wedding Halls'},




					
					
					



				  ];








let categorySelectBox    = document.querySelector('#category');
let subcategorySelectBox = document.querySelector('#subcategory');


let categoryOption = `<option> Select category </option>`;

for(let category of categoryArray)
{
	categoryOption += `<option value="${category.id}"> ${category.name} </option>`;
}
categorySelectBox.innerHTML = categoryOption;



categorySelectBox.addEventListener('change',function () {
	let counSelectedId   = Number.parseInt(categorySelectBox.value);
	let Selectsubcategory = subcategoryArray.filter(function(sub){
		return sub.sub_id === counSelectedId ;

	});



let subcategoryOption =`<option >Select Business title</option>`;
	for(let state of Selectsubcategory)
	{
		subcategoryOption +=`<option value="${state.sub_name}">${state.sub_name}</option>`
	}
	subcategorySelectBox.innerHTML = subcategoryOption;


});

