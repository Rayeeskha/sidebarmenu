<?php 
	
	$connection = mysqli_connect("localhost","root","", "online_store");
	




?>




