<?php
 include 'db/config.php'; 
  session_start();
  if(isset($_SESSION['Username'])){
     header("location:index.php?action=login");
} 

  echo '<a href="logout.php" >Logout</a>';


?>



<!doctype html>
<html lang="en">
  <head>
  	<title>Sidebar 02</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">

    <style type="text/css">
      body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Create a column layout with Flexbox */
.row {
  display: flex;
}

/* Left column (menu) */
.left {
  flex: 35%;
  padding: 15px 0;
}

.left h2 {
  padding-left: 8px;
}

/* Right column (page content) */
.right {
  flex: 65%;
  padding: 15px;
}

/* Style the search box */
#mySearch {
  width: 100%;
  font-size: 18px;
  padding: 11px;
  border: 1px solid #ddd;
}

/* Style the navigation menu inside the left column */
#myMenu {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myMenu li a {
  padding: 12px;
  text-decoration: none;
  color: black;
  display: block
}

#myMenu li a:hover {
  background-color: black;












}
</style>
 

  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">

			<nav id="sidebar">
    
				<div class="custom-menu">

					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4 pt-5">
		  		<h3 class="text-white bg-white"><a href="#" class="logo">
            <img src="images/business.jpg" class="img-thumbnail ">
               Capiled Team
          </a></h3>



         
            <form action="#" class="colorlib-subscribe-form">
              <div class="form-group d-flex">
                <div class="icon"><span class="icon-paper-plane"></span></div>
                 <input type="text" id="mySearch" onkeyup="myFunction()" placeholder="Search.." title="Type in a category" class="form-control">
              </div>
            </form>
          

	        <ul class="list-unstyled components mb-5" id="myMenu">

            <li>
                 <a href="./category/BusineesResistrastion.php" class="active bg-dark">Create Business Account</a>
               </li>
          
	          <li class="active">
	            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fab fa-hire-a-helper"></i> Anything On Hire</a>
	            <ul class="collapse list-unstyled" id="homeSubmenu">
                <li>
                  
                   <a href="#"> Car On Hire </a>
                </li>
                <li>
                    <a href="#">  Customer On Hire</a>
                </li>
                <li>
                    <a href="#">Bus on Hire</a>
                </li>
                  <li>
                    <a href="#">Tempos on Hire</a>
                </li>
                <li>
                    <a href="#">Mini Bus on Hire</a>
                </li>
                <li>
                    <a href="#">AC on Hire</a>
                </li>
                <li>
                    <a href="#">Rooms on Hire</a>
                </li>
                 <li>
                    <a href="#">Truck  on Hire</a>
                </li>
                  <li>
                    <a href="#">Vans  on Hire</a>
                </li>
	            </ul>
	          </li>
	       
	          
	          </li>

	            <li>
              <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">  Apply for Loans</a>
              <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#">  Home Loans</a>
                </li>
                <li>
                    <a href="#">Credit Card</a>
                </li>
                <li>
                    <a href="#">Persional Loan</a>
                </li>
                <li>
                    <a href="#">Business Loan</a>
                </li>
                <li>
                    <a href="#">Educational Loan</a>
                </li>
                 <li>
                    <a href="#">Loan Against Gold</a>
                </li>
              </ul>
	          </li>
	         <li>
                  <a href="#Submenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Auto Care</a>
                    <ul class="collapse list-unstyled" id="Submenu">
                      <li>
                          <a href="#"> <i class="fas fa-home"></i> car Repair</a>
                      </li>
                      <li>
                          <a href="#">car tyres</a>
                      </li>
                      <li>
                          <a href="#">car Batteries</a>
                      </li>
                      <li>
                          <a href="#">car Accessories</a>
                      </li>
                      <li>
                          <a href="#">Car Wash</a>
                      </li>
                       <li>
                          <a href="#">Motor Cycle Repair</a>
                      </li>
                      <li>
                          <a href="#">Scooter  Repair</a>
                      </li>
                      <li>
                          <a href="#">Two wheeler Tyres</a>
                      </li>
                       <li>
                          <a href="#">Two wheeler Batteries</a>
                      </li>
                       <li>
                          <a href="#">Two wheeler </a>
                      </li>
                    </ul>  
            </li>
	          <li>
                  <a href="#auto" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Automobile</a>
                    <ul class="collapse list-unstyled" id="auto">
                      <li>
                          <a href="#"> <i class="fas fa-home"></i> New Cars</a>
                      </li>
                      <li>
                          <a href="#">Used Cars</a>
                      </li>
                      <li>
                          <a href="#">Sell Cars</a>
                      </li>
                      <li>
                          <a href="#">Test Driver</a>
                      </li>
                     
                    </ul>  
                
            </li>

          <li>
                  <a href="#business" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>B2B</a>
                    <ul class="collapse list-unstyled" id="business">
                      <li>
                          <a href="#"> Electronics & Electrical Supplies</a>
                      </li>
                      <li>
                          <a href="#">Industrial Machinery & Equipments</a>
                      </li>
                      <li>
                          <a href="#">Construction Machinery & Supplies</a>
                      </li>
                      <li>
                          <a href="#">AutoMobile Spare Parts & Services</a>
                      </li>
                       <li>
                          <a href="#">Logestics & Transportation</a>
                      </li>
                        <li>
                          <a href="#">Industrial Supplies</a>
                      </li>
                     
                     
                    </ul>  
                
            </li>


               <li>
                  <a href="#babe" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Baby Care</a>
                    <ul class="collapse list-unstyled" id="babe">
                      <li>
                          <a href="#">  Baby Food</a>
                      </li>
                      <li>
                          <a href="#">Baby Sitters</a>
                      </li>
                      <li>
                          <a href="#">Baby Sleep</a>
                      </li>
                      <li>
                          <a href="#">Bath</a>
                      </li>
                      <li>
                          <a href="#">Books</a>
                      </li>
                       <li>
                          <a href="#">Clothes</a>
                      </li>
                      <li>
                          <a href="#">Creams</a>
                      </li>
                      <li>
                          <a href="#">Diapers</a>
                      </li>
                       <li>
                          <a href="#">Footware</a>
                      </li>
                       <li>
                          <a href="#">Grooming</a>
                      </li>
                      <li>
                          <a href="#">Safety</a>
                      </li>
                      <li>
                          <a href="#">Toys</a>
                      </li>
                      <li>
                          <a href="#">Health</a>
                      </li>
                    </ul>  
               </li>



               <li>
                  <a href="#banquets" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Banquets</a>
                    <ul class="collapse list-unstyled" id="banquets">
                      <li>
                          <a href="#"> All Banquets Halls</a>
                      </li>
                      <li>
                          <a href="#">5 Star Banquet Halls</a>
                      </li>
                      <li>
                          <a href="#">AC Banquet Halls</a>
                      </li>
                      <li>
                          <a href="#">Lawn For Events</a>
                      </li>
                      <li>
                          <a href="#">Non AC Banquets Halls</a>
                      </li>
                       <li>
                          <a href="#">Clothes</a>
                      </li>
                      <li>
                          <a href="#">Creams</a>
                      </li>
                      <li>
                          <a href="#">Diapers</a>
                      </li>
                       <li>
                          <a href="#">Footware</a>
                      </li>
                       <li>
                          <a href="#">Grooming</a>
                      </li>
                      <li>
                          <a href="#">Safety</a>
                      </li>
                      <li>
                          <a href="#">Toys</a>
                      </li>
                      <li>
                          <a href="#">Health</a>
                      </li>
                    </ul>  
               </li>
      
	          <li>
              <a href="#">Bills & Recharge</a>
	          </li>
             <li>
              <a href="#">Book HOtels</a>
            </li>
               <li>
              <a href="#">Books</a>
            </li>
            <li>
              <a href="#">Bus</a>
            </li>
             <li>
              <a href="#CAR" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Cabs & Car Rental|</a>
                    <ul class="collapse list-unstyled" id="CAR">
                      <li>
                          <a href="#"> BOOK A CAB ONLINE</a>
                      </li>
                      <li>
                          <a href="#">CAR RENTALS</a>
                      </li>
            </li>
	        </ul>


           <li>
                  <a href="#caterers" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Caterers</a>
                    <ul class="collapse list-unstyled" id="caterers">
                      <li>
                          <a href="#"> All caterers</a>
                      </li>
                      <li>
                          <a href="#">Birthday Party caterers</a>
                      </li>
                      <li>
                          <a href="#">Party Caterers</a>
                      </li>
                      <li>
                          <a href="#">Wedding Caterers</a>
                      </li>
                      <li>
                          <a href="#">Office caterers</a>
                      </li>
                    
                    </ul>  
               </li>

                <li>
                   <a href="#">Chemists</a>
               </li>

               <li>
                  <a href="#Contractors" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Civil Contractors</a>
                    <ul class="collapse list-unstyled" id="Contractors">
                      <li>
                          <a href="#"> Carpentry Contractors</a>
                      </li>
                      <li>
                          <a href="#">Civil Contractors</a>
                      </li>
                      <li>
                          <a href="#">Electrical Contractors</a>
                      </li>
                      <li>
                          <a href="#">Flooring Contractors</a>
                      </li>
                      <li>
                          <a href="#">Furniture Contractors</a>
                      </li>
                      <li>
                          <a href="#">Painting Contractors</a>
                      </li>
                       <li>
                          <a href="#">Plumbing Contractors</a>
                      </li>
                       <li>
                          <a href="#">Furniture Contractors</a>
                      </li>
                      <li>
                          <a href="#">Painting Contractors</a>
                      </li>
                      <li>
                          <a href="#">Welding Contractors</a>
                      </li>
                   </ul>  
               </li>

               <li>
                  <a href="#Courier" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>All Courier Services</a>
                    <ul class="collapse list-unstyled" id="Courier">
                      <li>
                          <a href="#">International</a>
                      </li>
                      <li>
                          <a href="#">Local</a>
                      </li>
                      <li>
                          <a href="#">National</a>
                      </li>
                      <li>
                          <a href="#">Bulk Courier</a>
                      </li>
                     
                   </ul>  
               </li>
                 <li>
                  <a href="#Needs" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Daily Needs</a>
                    <ul class="collapse list-unstyled" id="Needs">
                      <li>
                          <a href="#">Grocery</a>
                      </li>
                      <li>
                          <a href="#">Chemists</a>
                      </li>
                      <li>
                          <a href="#">Bakery</a>
                      </li>
                      <li>
                          <a href="#">Dairy Products</a>
                      </li>
                     <li>
                          <a href="#">Cakes </a>
                      </li>
                      <li>
                          <a href="#">Ice- Creams </a>
                      </li>
                   </ul>  
               </li>
                <li>
                  <a href="#dance" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Dance & Music</a>
                    <ul class="collapse list-unstyled" id="dance">
                      <li>
                          <a href="#">All Dance Classes</a>
                      </li>
                      <li>
                          <a href="#">Bollywood</a>
                      </li>
                      <li>
                          <a href="#">Classical Dance</a>
                      </li>
                      <li>
                          <a href="#">Hip HOP</a>
                      </li>
                     <li>
                          <a href="#">Salsa</a>
                      </li>
                     
                   </ul>  
               </li>
      
             <li>
                  <a href="#doctors" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Doctors</a>
                    <ul class="collapse list-unstyled" id="doctors">
                      <li>
                          <a href="#">Ayurvedic Doctors</a>
                      </li>
                      <li>
                          <a href="#">Cardiologists</a>
                      </li>
                      <li>
                          <a href="#">Chest Specialist</a>
                      </li>
                      <li>
                          <a href="#">Cosmatic Surgeons</a>
                      </li>
                     <li>
                          <a href="#">Dentists</a>
                      </li>
                        <li>
                          <a href="#">Dermatologists</a>
                      </li>
                       <li>
                          <a href="#">Dietitians</a>
                      </li>
                       <li>
                          <a href="#">ENT Specialists</a>
                      </li>
                       <li>
                          <a href="#">Gastroenterologists Specialists</a>
                      </li>
                      <li>
                          <a href="#">General Physicians</a>
                      </li>
                      <li>
                          <a href="#">Gynaecologist & Obstetricians</a>
                      </li>
                       <li>
                          <a href="#">Homeopathic Doctors</a>
                      </li>
                       <li>
                          <a href="#">Neurologists</a>
                      </li>
                       <li>
                          <a href="#">Neurosurgeons</a>
                      </li>
                       <li>
                          <a href="#">On Call Doctors</a>
                      </li>
                      <li>
                          <a href="#">Paeditricians</a>
                      </li>
                       <li>
                          <a href="#">Physiotherapists for Home Visit</a>
                      </li>
                       <li>
                          <a href="#">Physiotherapists</a>
                      </li>
                      <li>
                          <a href="#">Piles Doctors</a>
                      </li>
                        <li>
                          <a href="#">Sexologists</a>
                      </li>
                        <li>
                          <a href="#">Skin & Hair Doctors</a>
                      </li>
                   </ul>  
               </li>




             <li>
                  <a href="#education" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Education</a>
                    <ul class="collapse list-unstyled" id="education">
                      <li>
                          <a href="#">School</a>
                      </li>
                      <li>
                          <a href="#">Collages</a>
                      </li>
                      <li>
                          <a href="#">Acting Classes</a>
                      </li>
                      <li>
                          <a href="#">Art & Craft classes</a>
                      </li>
                     <li>
                          <a href="#">Coaching Classes & Tutorial</a>
                      </li>
                        <li>
                          <a href="#">Language Classes</a>
                      </li>
                       <li>
                          <a href="#">Music Classes</a>
                      </li>
                       <li>
                          <a href="#">Painting classes</a>
                      </li>
                       <li>
                          <a href="#">Photography Classes</a>
                      </li>
                      <li>
                          <a href="#">Soft skill & Image Building</a>
                      </li>
                      <li>
                          <a href="#">Training Institute</a>
                      </li>
                       
                   </ul>  
               </li>


             <li>
                  <a href="#emergency" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Emergency</a>
                    <ul class="collapse list-unstyled" id="emergency">
                      <li>
                          <a href="#">24 HOURS Chemists</a>
                      </li>
                      <li>
                          <a href="#">Ambulance Service</a>
                      </li>
                      <li>
                          <a href="#">Blood Bank</a>
                      </li>
                      <li>
                          <a href="#">Cardiologists</a>
                      </li>
                     <li>
                          <a href="#">Duplicate Key Stores</a>
                      </li>
                        <li>
                          <a href="#">Fire Brigade</a>
                      </li>
                       <li>
                          <a href="#">Hospitals</a>
                      </li>
                       <li>
                          <a href="#">Police</a>
                      </li>
                       <li>
                          <a href="#">Snake catchers</a>
                      </li>
                      <li>
                          <a href="#">Towing Services</a>
                      </li>
                      
                       
                   </ul>  
               </li>
               <li>
                 <a href="#">Entertainment</a>
               </li>

                 <li>
                  <a href="#event" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Event Organizers</a>
                    <ul class="collapse list-unstyled" id="event">
                      <li>
                          <a href="#">Carporate Parties</a>
                      </li>
                      <li>
                          <a href="#">Private Partise</a>
                      </li>
                      <li>
                          <a href="#">Seminar Organizers</a>
                      </li>
                      <li>
                          <a href="#">Stage show Organizers</a>
                      </li>
                     <li>
                          <a href="#">Trade Fade Organizers</a>
                      </li>
                        <li>
                          <a href="#">Wedding Organizers</a>
                      </li>
                       <li>
                          <a href="#">Hospitals</a>
                      </li>
                       <li>
                          <a href="#">Police</a>
                      </li>
                       <li>
                          <a href="#">Snake catchers</a>
                      </li>
                      <li>
                          <a href="#">Towing Services</a>
                      </li>
                      
                       
                   </ul>  
               </li>

                 <li>
                  <a href="#fitness" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Fitness</a>
                    <ul class="collapse list-unstyled" id="fitness">
                      <li>
                          <a href="#">Dietitians</a>
                      </li>
                      <li>
                          <a href="#">Fitness Classes</a>
                      </li>
                      <li>
                          <a href="#">Gym</a>
                      </li>
                      <li>
                          <a href="#">Health Equipments</a>
                      </li>
                     <li>
                          <a href="#">Health Food & Suppliments</a>
                      </li>
                        <li>
                          <a href="#">Meditation & Relaxation</a>
                      </li>
                       <li>
                          <a href="#">Pilates Studios</a>
                      </li>
                       <li>
                          <a href="#">Reformer Studies</a>
                      </li>
                       <li>
                          <a href="#">Sport Club</a>
                      </li>
                      <li>
                          <a href="#">Weight Reduction</a>
                      </li>
                       <li>
                          <a href="#">Yoga Classes</a>
                      </li>
                      
                       
                   </ul>  
               </li>
               <li>
                 <a href="#"><i class="fas fa-helicopter"></i> Flights</a>
               </li>
               <li>
                 <a href="#">Foreign-Exchange</a>
               </li>
                
                 <li>
                  <a href="#flower" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Florists</a>
                    <ul class="collapse list-unstyled" id="flower">
                      <li>
                          <a href="#">Flower Shops</a>
                      </li>
                      <li>
                          <a href="#">Florists Home Delivery</a>
                      </li>
                      <li>
                          <a href="#">24 Hours Florists</a>
                      </li>
                      <li>
                          <a href="#">Florists For Wedding Decoratrion </a>
                      </li>
                   </ul>  
               </li>
                 <li>
                  <a href="#DECOR" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Home Decor</a>
                    <ul class="collapse list-unstyled" id="DECOR">
                      <li>
                          <a href="#">Furnitures</a>
                      </li>
                      <li>
                          <a href="#">Furnishing</a>
                      </li>
                      <li>
                          <a href="#">Lamp & Lighting </a>
                      </li>
                      <li>
                          <a href="#">Kitchen & Dine </a>
                      </li>
                     <li>
                          <a href="#">Bath</a>
                      </li>
                      <li>
                          <a href="#">House Keeping</a>
                      </li>
                    
                      
                       
                   </ul>  
               </li>
                 <li>
                  <a href="#improve" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Home Improvements</a>
                    <ul class="collapse list-unstyled" id="improve">
                      <li>
                          <a href="#">Architects & Engineers</a>
                      </li>
                      <li>
                          <a href="#">Carpets</a>
                      </li>
                      <li>
                          <a href="#">Flooring </a>
                      </li>
                      <li>
                          <a href="#">Insulation </a>
                      </li>
                     <li>
                          <a href="#">Modular Kitchens</a>
                      </li>
                      <li>
                          <a href="#">Paintings</a>
                      </li>
                      <li>
                          <a href="#">Swimming Pools</a>
                      </li>
                      <li>
                          <a href="#">Wall claddings</a>
                      </li>
                      <li>
                          <a href="#">Wall Papers</a>
                      </li>
                  </ul>  
               </li>
                 <li>
                  <a href="#hospitals" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Hospitals</a>
                    <ul class="collapse list-unstyled" id="hospitals">
                      <li>
                          <a href="#">Children Hospitals</a>
                      </li>
                      <li>
                          <a href="#">ENT Hospitals</a>
                      </li>
                      <li>
                          <a href="#">Eye Hospitals </a>
                      </li>
                      <li>
                          <a href="#">Maternity Hospitals </a>
                      </li>
                     <li>
                          <a href="#">Mental Hospitals</a>
                      </li>
                      <li>
                          <a href="#">Multispeciality Hospitals</a>
                      </li>
                      <li>
                          <a href="#">Private Hospitals</a>
                      </li>
                      <li>
                          <a href="#">Veterinary Hospitals</a>
                      </li>
                     
                  </ul>  
               </li>
               <li>
                 <a href="#">Hotels</a>
               </li>

              <li>
                  <a href="#hOUSE" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>House Keeping</a>
                    <ul class="collapse list-unstyled" id="hOUSE">
                      <li>
                          <a href="#">Cooks</a>
                      </li>
                      <li>
                          <a href="#">Maids</a>
                      </li>
                      <li>
                          <a href="#">Drivers</a>
                      </li>
                      <li>
                          <a href="#">Laundary Services </a>
                      </li>
                     <li>
                          <a href="#">Cleaning Services</a>
                      </li>
                      <li>
                          <a href="#">Pest Control</a>
                      </li>
                    
                     
                  </ul>  
               </li>
                <li>
                  <a href="#indeus" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Industrial Products</a>
                    <ul class="collapse list-unstyled" id="indeus">
                      <li>
                          <a href="#">Industrial Parts</a>
                      </li>
                      <li>
                          <a href="#">Industrial Tools</a>
                      </li>
                      <li>
                          <a href="#"> Industry Specific Mashine</a>
                      </li>
                      <li>
                          <a href="#">Welding Equipmets & Machines </a>
                      </li>
                    
                    
                     
                  </ul>  
               </li>
               <li>
                 <a href="#">Insurance3</a>
               </li>
                  <li>
                  <a href="#int" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i> Designers For College</a>
                    <ul class="collapse list-unstyled" id="int">
                      <li>
                          <a href="#">Architects</a>
                      </li>
                      <li>
                          <a href="#">Residence</a>
                      </li>
                      <li>
                          <a href="#"> Commercial</a>
                      </li>
                      <li>
                          <a href="#">Interior Designer Institutes </a>
                      </li>
                    
                  </ul>  
               </li>

               <li>
                 <a href="#">International Sim Cards</a>
               </li>

                 <li>
                  <a href="#internet" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Internet</a>
                    <ul class="collapse list-unstyled" id="internet">
                      <li>
                          <a href="#">Internet Service Provider</a>
                      </li>
                      <li>
                          <a href="#">Web Designers</a>
                      </li>
                      <li>
                          <a href="#"> Cyber Cafes</a>
                      </li>
                      <li>
                          <a href="#">Wifi Internet Service Providers</a>
                      </li>
                    
                  </ul>  
               </li>
               <li>
                 <a href="#">Jobs</a>
               </li>
                   <li>
                  <a href="#Jewellery" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Jewellery</a>
                    <ul class="collapse list-unstyled" id="Jewellery">
                      <li>
                          <a href="#">ALL Jewellery</a>
                      </li>
                      <li>
                          <a href="#">Bridal Jewellery</a>
                      </li>
                      <li>
                          <a href="#">Bangles</a>
                      </li>
                      <li>
                          <a href="#">Bracelets</a>
                      </li>
                      <li>
                          <a href="#">Gold Coins</a>
                      </li>
                      <li>
                          <a href="#">Chains</a>
                      </li>
                      <li>
                          <a href="#">Earrings</a>
                      </li>
                      <li>
                          <a href="#">Mangalsutras</a>
                      </li>
                      <li>
                          <a href="#">Necklaces</a>
                      </li>
                      <li>
                          <a href="#">Nose Pins</a>
                      </li>
                      <li>
                          <a href="#">Pendents</a>
                      </li>
                      <li>
                          <a href="#">Rings</a>
                      </li>
                  </ul>  
               </li>

                <li>
                  <a href="#">Labs</a>
                </li>

                
                 <li>
                  <a href="#languages" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Language Classes</a>
                    <ul class="collapse list-unstyled" id="languages">
                      <li>
                          <a href="#">Arabic</a>
                      </li>
                      <li>
                          <a href="#">Chinese</a>
                      </li>
                      <li>
                          <a href="#">English</a>
                      </li>
                      <li>
                          <a href="#">French</a>
                      </li>
                      <li>
                          <a href="#">German</a>
                      </li>
                      <li>
                          <a href="#">Hindi</a>
                      </li>
                      <li>
                          <a href="#">Italian</a>
                      </li>
                      <li>
                          <a href="#">Japanese</a>
                      </li>
                      <li>
                          <a href="#">Russian</a>
                      </li>
                      <li>
                          <a href="#">Spanish</a>
                      </li>
                      
                  </ul>  
               </li>

                   <li>
                  <a href="#medical" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Medical</a>
                    <ul class="collapse list-unstyled" id="medical">
                      <li>
                          <a href="#">Doctors</a>
                      </li>
                      <li>
                          <a href="#">Hopitals</a>
                      </li>
                      <li>
                          <a href="#">Dentists</a>
                      </li>
                      <li>
                          <a href="#">Chemists</a>
                      </li>
                      <li>
                          <a href="#">Pathology Labs</a>
                      </li>
                      <li>
                          <a href="#">Ambulance</a>
                      </li>
                      <li>
                          <a href="#">Opticians</a>
                      </li>
                      <li>
                          <a href="#">Blood Banks</a>
                      </li>
                     
                  </ul>  
               </li>

                 <li>
                  <a href="#kitchen" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Modular Kitchen</a>
                    <ul class="collapse list-unstyled" id="kitchen">
                      <li>
                          <a href="#">Cabinets</a>
                      </li>
                      <li>
                          <a href="#">Chimneys</a>
                      </li>
                      <li>
                          <a href="#">Gas Stoves</a>
                      </li>
                      <li>
                          <a href="#">Built in Hobs</a>
                      </li>
                      <li>
                          <a href="#">Shutters</a>
                      </li>
                      <li>
                          <a href="#">L shaped Kitchen</a>
                      </li>
                      
                  </ul>  
               </li>
               <li>
                 <a href="#">Movies</a>
               </li>

                 <li>
                  <a href="#home" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Home Services</a>
                    <ul class="collapse list-unstyled" id="home">
                      <li>
                          <a href="#">Carpenters</a>
                      </li>
                      <li>
                          <a href="#">Carpet Cleaners</a>
                      </li>
                      <li>
                          <a href="#">Driver Service</a>
                      </li>
                      <li>
                          <a href="#">Duplicate Key Makers</a>
                      </li>
                      <li>
                          <a href="#">Electricians</a>
                      </li>
                      <li>
                          <a href="#">Masons</a>
                      </li>
                      <li>
                          <a href="#">Painters</a>
                      </li>
                       <li>
                          <a href="#">Pest Controlls</a>
                      </li>
                       <li>
                          <a href="#">Plumbers</a>
                      </li>
                      <li>
                          <a href="#">Towing Services</a>
                      </li>
                      <li>
                          <a href="#">Carpet Contractors</a>
                      </li>
                       <li>
                          <a href="#">Electric Chimney</a>
                      </li>
                      
                      <li>
                          <a href="#">Fire Fighting Contractors</a>
                      </li>
                      <li>
                          <a href="#">Flooring Contractors</a>
                      </li>
                      <li>
                          <a href="#">Civil Contractors</a>
                      </li>
                      <li>
                          <a href="#"> Gardening Tools Services</a>
                      </li>
                      <li>
                          <a href="#"> House Keeping Cleaning</a>
                      </li>
                      <li>
                          <a href="#">Interior Designers Architecture</a>
                      </li>
                       <li>
                          <a href="#">Interior Decorators</a>
                      </li>
                      <li>
                          <a href="#">Internet Service Providers</a>
                      </li>
                      <li>
                          <a href="#">Lock Repair Services</a>
                      </li>
                      <li>
                          <a href="#">Architects</a>
                      </li>
                      <li>
                          <a href="#">Packaging Labelling</a>
                      </li>
                      <li>
                          <a href="#">Swimming Contractors</a>
                      </li>
                       <li>
                          <a href="#">Painting Contractors</a>
                      </li>
                      <li>
                          <a href="#">Roofing Contractors</a>
                      </li>
                      <li>
                          <a href="#">Security Equipment Services</a>
                      </li>
                      <li>
                          <a href="#">DTH</a>
                      </li>
                      <li>
                        <a href="#">Wall Paper Contractors</a>
                      </li>
                      <li>
                        <a href="#">Water Proofing Contractors</a>
                      </li>

                  </ul>  
               </li>


               <li>
                  <a href="#movers" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Packers & Movers</a>
                    <ul class="collapse list-unstyled" id="movers">
                      <li>
                          <a href="#">All Options</a>
                      </li>
                      <li>
                          <a href="#">Local</a>
                      </li>
                      <li>
                          <a href="#">National</a>
                      </li>
                      <li>
                          <a href="#">International</a>
                      </li>
                      <li>
                          <a href="#">Movers For Automobile</a>
                      </li>
                      <li>
                          <a href="#">Movers For Commercial</a>
                      </li>
                      
                  </ul>  
               </li>

                <li>
                  <a href="#party" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Party</a>
                    <ul class="collapse list-unstyled" id="party">
                      <li>
                          <a href="#">Banquet Halls</a>
                      </li>
                      <li>
                          <a href="#">DJ on Hire</a>
                      </li>
                      <li>
                          <a href="#">Event Organisers</a>
                      </li>
                      <li>
                          <a href="#">Photographers</a>
                      </li>
                      <li>
                          <a href="#">Wine Retailers</a>
                      </li>
                      <li>
                          <a href="#">Party Organisers For Children</a>
                      </li>
                      <li>
                        <a href="#">Playback Singers</a>
                      </li>
                      
                  </ul>  
               </li>
                  <li>
                  <a href="#persional" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Persional Care </a>
                    <ul class="collapse list-unstyled" id="persional">
                      <li>
                          <a href="#">Beauty Parlours</a>
                      </li>
                      <li>
                          <a href="#">Beauty Services</a>
                      </li>
                      <li>
                          <a href="#">Bridal Makeup</a>
                      </li>
                      <li>
                          <a href="#">Bridegroom Makeup</a>
                      </li>
                      <li>
                          <a href="#">Salons</a>
                      </li>
                      <li>
                          <a href="#">Spas</a>
                      </li>
                      
                  </ul>  
               </li>

                <li>
                  <a href="#control" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Pest Control </a>
                    <ul class="collapse list-unstyled" id="control">
                      <li>
                          <a href="#">Pest Control</a>
                      </li>
                      <li>
                          <a href="#">Commercial Pest Control</a>
                      </li>
                      <li>
                          <a href="#">Residential Pest Control</a>
                      </li>
                      <li>
                          <a href="#">Bird Control</a>
                      </li>
                      <li>
                          <a href="#">Cockroach Control</a>
                      </li>
                      <li>
                          <a href="#">Commercial Pest Control</a>
                      </li>
                       <li>
                          <a href="#">Fly Control</a>
                      </li>
                      
                  </ul>  
               </li>

                <li>
                  <a href="#care" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Pet & Pet Care</a>
                    <ul class="collapse list-unstyled" id="care">
                      <li>
                          <a href="#">Pet Accessories</a>
                      </li>
                      <li>
                          <a href="#">Pet Food</a>
                      </li>
                      <li>
                          <a href="#">Pet Shops</a>
                      </li>
                      <li>
                          <a href="#">Birds</a>
                      </li>
                      <li>
                          <a href="#">Fish</a>
                      </li>
                      <li>
                          <a href="#">Small Pets</a>
                      </li>
                       
                      
                  </ul>  
               </li>
                <li>
                  <a href="#school" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Play Schools</a>
                    <ul class="collapse list-unstyled" id="school">
                      <li>
                          <a href="#">Kindergarten</a>
                      </li>
                      <li>
                          <a href="#">Montessori Schools</a>
                      </li>
                      <li>
                          <a href="#">Play Schools</a>
                      </li>
                      <li>
                          <a href="#">Pre-School</a>
                      </li>
                   
                       
                      
                  </ul>  
               </li>
                 <li>
                  <a href="#real" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Real Estate</a>
                    <ul class="collapse list-unstyled" id="real">
                      <li>
                          <a href="#">Rent</a>
                      </li>
                      <li>
                          <a href="#">Sell</a>
                      </li>
                      <li>
                          <a href="#">PG, Hostels and Rooms</a>
                      </li>
                     
                      
                  </ul>  
               </li>

               <li>
                  <a href="#Repairs" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Repairs</a>
                    <ul class="collapse list-unstyled" id="Repairs">
                      <li>
                          <a href="#">AC</a>
                      </li>
                      <li>
                          <a href="#">Car</a>
                      </li>
                      <li>
                          <a href="#">Computer</a>
                      </li>
                      <li>
                          <a href="#">Laptop</a>
                      </li>
                      <li>
                          <a href="#">Mobile Phone</a>
                      </li>
                      <li>
                          <a href="#">Motorcycle</a>
                      </li>
                      <li>
                        <a href="#">Refrigerator</a>
                      </li>
                      <li>
                        <a href="#">Washing Machine</a>
                      </li>
                      <li>
                        <a href="#">Water Purifier</a>
                      </li>
                       
                      
                  </ul>  
               </li>
               <li>
                 <a href="#">Restaurants</a>
               </li>
               <li>
                 <a href="#">Shop Online</a>
               </li>

               <li>
                  <a href="#security" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Security Services</a>
                    <ul class="collapse list-unstyled" id="security">
                      <li>
                          <a href="#">Bodyguards</a>
                      </li>
                      <li>
                          <a href="#">CCTV Cameras</a>
                      </li>
                      <li>
                          <a href="#">Hire Detectives</a>
                      </li>
                      <li>
                          <a href="#">Lock</a>
                      </li>
                      <li>
                          <a href="#">Lock Repair & Services</a>
                      </li>
                      <li>
                          <a href="#">Security Services</a>
                      </li>
                      <li>
                        <a href="#">Valet Parking Services</a>
                      </li>
                      <li>
                        <a href="#">Walkie Talkie Dealers</a>
                      </li>
                     
                      
                  </ul>  
               </li>
                 <li>
                  <a href="#shopping" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Shopping</a>
                    <ul class="collapse list-unstyled" id="shopping">
                      <li>
                          <a href="#">Shopping For Men</a>
                      </li>
                      <li>
                          <a href="#">Shopping For Women</a>
                      </li>
                      <li>
                          <a href="#">Shopping For Kids</a>
                      </li>      
                  </ul>  
               </li>


               <li>
                  <a href="#sport" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Sports Coach</a>
                    <ul class="collapse list-unstyled" id="sport">
                      <li>
                          <a href="#">Athletics</a>
                      </li>
                      <li>
                          <a href="#">Badminton</a>
                      </li>
                      <li>
                          <a href="#">Basketball</a>
                      </li>
                      <li>
                          <a href="#">Boxing</a>
                      </li>
                      <li>
                          <a href="#">Chess</a>
                      </li>
                      <li>
                          <a href="#">Cricket</a>
                      </li>
                      <li>
                        <a href="#">Football</a>
                      </li>
                      <li>
                        <a href="#">Gymnastic</a>
                      </li>
                     <li>
                       <a href="#">Hockey</a>
                     </li>
                      <li>
                        <a href="#">Judo</a>
                      </li>
                      <li>
                        <a href="#">Karate</a>
                      </li>
                      <li>
                        <a href="#">Skating</a>
                      </li>
                      <li>
                        <a href="#">Squash</a>
                      </li>
                      <li>
                        <a href="#">Swimming</a>
                      </li>
                      <li>
                        <a href="#">Table Tennis</a>
                      </li>
                      <li>
                        <a href="#">Tennis</a>
                      </li>
                      <li>
                        <a href="#">Volleyball</a>
                      </li>
                  </ul>  
               </li>


               <li>
                  <a href="#sportgo9ods" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Sports Goods</a>
                    <ul class="collapse list-unstyled" id="sportgo9ods">
                      <li>
                          <a href="#">Basketball</a>
                      </li>
                      <li>
                          <a href="#">Billiards & Pool</a>
                      </li>
                      <li>
                          <a href="#">Cricket</a>
                      </li>
                      <li>
                          <a href="#">Cycling</a>
                      </li>
                      <li>
                          <a href="#">Football</a>
                      </li>
                      <li>
                          <a href="#">Golf</a>
                      </li>
                      <li>
                        <a href="#">Hiking And Camping</a>
                      </li>
                      <li>
                        <a href="#">Hockey</a>
                      </li>
                     <li>
                       <a href="#">Skating</a>
                     </li>
                      <li>
                        <a href="#">Squash</a>
                      </li>
                      <li>
                        <a href="#">Swimming</a>
                      </li>
                      <li>
                        <a href="#">Tennis</a>
                      </li>
                     
                  </ul>  
               </li>
               <li>
                 <a href="#">Train</a>
               </li>

                  <li>
                  <a href="#institute" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Training Institutes For SAP</a>
                    <ul class="collapse list-unstyled" id="institute">
                      <li>
                          <a href="#">Administration Training</a>
                      </li>
                      <li>
                          <a href="#">Basic Computing</a>
                      </li>
                      <li>
                          <a href="#">Computer Hardware Training</a>
                      </li>
                      <li>
                          <a href="#">Computer Networking Training</a>
                      </li>
                      <li>
                          <a href="#">Database Training</a>
                      </li>
                      <li>
                          <a href="#">Engineering Design Training</a>
                      </li>
                      <li>
                        <a href="#">Mobile Development Training</a>
                      </li>
                      <li>
                        <a href="#">Multimedia & Design Training</a>
                      </li>
                     <li>
                       <a href="#">Programming Languages</a>
                     </li>
                      <li>
                        <a href="#">Web Technology Training</a>
                      </li>
                    
                     
                  </ul>  
               </li>

               <li>
                  <a href="#Transporters" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Transporters</a>
                    <ul class="collapse list-unstyled" id="Transporters">
                      <li>
                          <a href="#">Animal Transporters</a>
                      </li>
                      <li>
                          <a href="#">Antiques & Special Care Items</a>
                      </li>
                      <li>
                          <a href="#">Business & Industrial Goods</a>
                      </li>
                      <li>
                          <a href="#">Food & Agriculture Products</a>
                      </li>
                      <li>
                          <a href="#">Full Container Load Freight</a>
                      </li>
                      <li>
                          <a href="#">Household Goods</a>
                      </li>
                      <li>
                        <a href="#">Junk Transporters</a>
                      </li>
                      <li>
                        <a href="#">Low Container Load Freight</a>
                      </li>
                     <li>
                       <a href="#">Plants & Heavy Equipments</a>
                     </li>
                      <li>
                        <a href="#">Vehicles Transporters</a>
                      </li>
                    
                     
                  </ul>  
               </li>
                 <li>
                  <a href="#Travel" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Travel</a>
                    <ul class="collapse list-unstyled" id="Travel">
                      <li>
                          <a href="#">Hotels</a>
                      </li>
                      <li>
                          <a href="#">Flights</a>
                      </li>
                      <li>
                          <a href="#">Bus</a>
                      </li>
                      <li>
                          <a href="#">Car Rentals</a>
                      </li>
                      <li>
                          <a href="#">Cabs</a>
                      </li>
                      <li>
                          <a href="#">Trains</a>
                      </li>
                      <li>
                        <a href="#">International SIM Card</a>
                      </li>
                      <li>
                        <a href="#">Visa</a>
                      </li>
                     <li>
                       <a href="#">Foreign Exchange</a>
                     </li>
                      <li>
                        <a href="#">Meals On Train</a>
                      </li>
                    <li>
                      <a href="#">Tempo Travellers</a>
                    </li>
                     
                  </ul>  
               </li>
                 <li>
                  <a href="#Wedding" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"> <i class="fas fa-car-side"></i>Wedding</a>
                    <ul class="collapse list-unstyled" id="Wedding">
                      <li>
                          <a href="#">Banquet Halls</a>
                      </li>
                      <li>
                          <a href="#">Bridal Requisites</a>
                      </li>
                      <li>
                          <a href="#">Florists</a>
                      </li>
                      <li>
                          <a href="#">Jewellery</a>
                      </li>
                      <li>
                          <a href="#">Matrimonial Bureaus</a>
                      </li>
                      <li>
                          <a href="#">Photographers</a>
                      </li>
                      <li>
                        <a href="#">Wedding Cards</a>
                      </li>
                      <li>
                        <a href="#">Visa</a>
                      </li>
                     <li>
                       <a href="#">Foreign Exchange</a>
                     </li>
                      <li>
                        <a href="#">Meals On Train</a>
                      </li>
                    <li>
                      <a href="#">Tempo Travellers</a>
                    </li>
                    <li>
                      <a href="#">DJ On Hire</a>
                    </li>
                    <li>
                      <a href="#">Dance Groups</a>
                    </li>
                     <li>
                       <a href="#">Dhol Players</a>
                     </li>
                     <li>
                       <a href="#">Doli On Hire</a>
                     </li>
                     <li>
                       <a href="#">Event Organisers</a>
                     </li>
                     <li>
                       <a href="#">Fireworks</a>
                     </li>
                     <li>
                       <a href="#">Florists</a>
                     </li>
                     <li>
                       <a href="#">Flower Decorators</a>
                     </li>
                     <li>
                       <a href="#">Generator & Power Backup</a>
                     </li>
                    <li>
                      <a href="#">Guest Houses</a>
                    </li>
                    <li>
                      <a href="#">Horses On Hire</a>
                    </li>
                    <li>
                      <a href="#">Jewellery</a>
                    </li>
                    <li>
                      <a href="#">Juice Services</a>
                    </li>
                    <li>
                      <a href="#">Kids Entertainment</a>
                    </li>
                    <li>
                      <a href="#">Mandap Decorator</a>
                    </li>
                    <li>
                      <a href="#">Marriage Gardens</a>
                    </li>
                    <li>
                      <a href="#">Matrimonial Bureaus</a>
                    </li>
                    <li>
                      <a href="#">Mehendi Artists</a>
                    </li>
                    <li>
                      <a href="#">Music Bands</a>
                    </li>
                    <li>
                      <a href="#">Paan Suppliers</a>
                    </li>
                    <li>
                      <a href="#">Pandits</a>
                    </li>
                    <li>
                      <a href="#">Photographers</a>
                    </li>
                    <li>
                      <a href="#">Readymade Garment Retailer</a>
                    </li>
                    <li>
                      <a href="#">Sound System On Hire</a>
                    </li>
                    <li>
                      <a href="#">Sweet Shops</a>
                    </li>
                    <li>
                      <a href="#">Tent House</a>
                    </li>
                    <li>
                      <a href="#">Wedding Cards</a>
                    </li>
                    <li>
                      <a href="#">Wedding Grocery</a>
                    </li>
                    <li>
                      <a href="#">Wedding Halls</a>
                    </li>
                  </ul>  
               </li>
               
               <li>
                 <a href="./category/BusineesResistrastionShowdata.php">Registered Business User</a>
               </li>


	        <div class="footer">
	        	<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Capiled Team <a href="#" target="_blank"></a>
						  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
	        </div>

	      </div>
    	</nav>

        <!-- Page Content  -->

      <div id="content" class="p-4 p-md-5 pt-5">
   <div class="card ">
       
  
    
      
     
      <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 table-responsive">

        <table class="table table-border table-striped table-hover  text-center">
          <thead>
           
            <th>Name</th>
            <th>Profile Pics</th>
            
            <th>Business Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            
            <th>Website URL</th>
            <th>Products</th>
            
            <th>Sub Categtory</th>
            <th>Description</th>
          </thead>
          <tbody>
            <?php

              $query = "SELECT  * FROM   business_account_form ";

              $querydisplay = mysqli_query($connection, $query);

              while ($result = mysqli_fetch_array($querydisplay)) {
                # code...
                ?>
                <tr>
                  
                  <td><?php echo $result['NAME'] ?></td>
                  <td><img src="<?php echo $result['IMAGE']; ?>" height="100px" width="100px"></td>
                  
                  <td><?php echo $result['BUSINESS_NAME'] ?></td>
                  <td><?php echo $result['PHONE_NUMBER'] ?></td>
                  <td><?php echo $result['EMAIL'] ?></td>
                  
                  <td><?php echo $result['WEBSITE_URL'] ?></td>
                  <td><?php echo $result['PRODUCTS'] ?></td>
                  
                  <td><?php echo $result['SUB_CATEGORY'] ?></td>
                  <td><?php echo $result['DISCRIPTION'] ?></td>
                </tr>
                <?php
              }





             ?>
          </tbody>
      </div>
      
    </div>
  </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>

<script>
function myFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("mySearch");
  filter = input.value.toUpperCase();
  ul = document.getElementById("myMenu");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
</script>

