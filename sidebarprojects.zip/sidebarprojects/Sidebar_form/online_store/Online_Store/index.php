<?php include "db/config.php";
	session_start();

	if (isset($_SESSION["Username"])) {
		# code...
		header("location:index.php");
	}
 ?>
<?php 

if(isset($_POST['Register'])){
		


				$firstname	 = mysqli_real_escape_string($connection,$_POST['firstname']);
				$lastname	 = mysqli_real_escape_string($connection,$_POST['lastname']);
				$Username	 = mysqli_real_escape_string($connection,$_POST['Username']);
				$Email 		 = mysqli_real_escape_string($connection,$_POST['email']);
				$phonenumber = mysqli_real_escape_string($connection,$_POST['phonenumber']);
				$password    = mysqli_real_escape_string($connection,$_POST['password']);
				$password = md5($password);
				$Gender    = mysqli_real_escape_string($connection,$_POST['gender']);
				

			
					# code...
				
					$query = "INSERT INTO  signup_user (FIRST_NAME,LAST_NAME,USERNAME, EMAIL_ID, PHONE_NUMBER, PASSWORD,gender)
					VALUES('$firstname','$lastname','$Username','$Email','$phonenumber','$password','$Gender')";

					if(mysqli_query($connection,$query)){
						echo "<div class='container col-md-6 col-sm-12 col-lg-3 py-5'>
								<div class='alert alert-success'>
								  <strong>Success!</strong> Successfully Registered Go to Login <a href='index.php?action=login' class='btn btn-secondary'>Login</a>.
								</div>
							</div>";
					}else{
						echo '<div class="col-md-6">
								<div class="alert alert-warning">
									  <strong>Warning!</strong> Invalid Login Details.
								</div>
							</div>';
					}

	}

  
?>







<?php

	if (isset($_POST["login"])) {
		# code...
		if (empty($POST["Username"]) && empty($_POST['password'])) {
			# code...
			echo "<script>alert('Both Fields are required')</script>";

		}else{
			$Username = mysqli_real_escape_string($connection, $_POST["Username"]);
			$Password = mysqli_real_escape_string($connection, $_POST["password"]);
			$password = md5($Password);

			$query = "SELECT * FROM signup_user WHERE USERNAME = '$Username' AND 	PASSWORD = '$password' ";

			$result = mysqli_query($connection, $query);
			if (mysqli_num_rows($result) > 0) {
				# code...
				$_SESSION['Username'] = $username;
				header("location:Menu.php");
			}else{
				echo "<script>alert('Wrong user Details') </script>";
			}
		}
	}

?>




<!DOCTYPE html>
<html>
<head>
	<title>ONLINE Store Form validation </title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<style>


 body{
 		 background-image: url("images/company.jpg") !important;
  		background-repeat: repeat-x;
  		  background-attachment: fixed !important;
  		  
 }
 .error {color: #FF0000;}
</style>
</head>
<body>









<div class="container  py-5">


<!-- Card -->
<div class="col-md-8 col-sm-12 col-lg-7">
<div class="card">
	
  <!-- Card body -->
  <div class="card-body">


    <!-- Material form register -->
    <form method="post" action="">





<?php 

	if (isset($_GET["action"]) == "login") {
		# code...

	

	?>

	
	<div class="container ">
	

		<p class="h4 text-center py-2">LOGIN</p>
		<div class="row">
	

	<form method="post" name="registration">
		
			<label>Enter Username</label>
			<input type="text" required="" onautocomplete="off" name="Username" class="form-control" />
		
		<label>Enter Password</label>
		<input type="password" required="" onautocomplete="off" name="password" class="form-control" />
		<a href="Requestreset.php" class= "#"> ResetPassword</a>
		
		<div class="mt-5">
			<input type="submit" name="login" value="login" class="btn btn-info">
			<a href="index.php" class="btn btn-secondary">Register</a>
		</div>
	</form>
	</div>
</div>
</div>
	<?php
	 
		}
		else
		{

		?>

	    <!-- Material input text -->
<div class="card">
      <p class="h4 text-center py-4">Resgistration</p>


      <div class="panel-body">
                            
                            <form class="form-horizontal" action="." id="form1">
                                
                                <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="First_Name">First Name</label></div>
                                    <div class="col-lg-12">
                                        <input type="text" name="firstname" required="" id="name" class="form-control required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="Last_Name">Last Name</label></div>
                                    <div class="col-lg-12">
                                        <input type="text" name="lastname" re id="username" class="form-control really-simple required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="username" onautocomplete="off">Username</label></div>
                                    <div class="col-lg-12">
                                        <input type="text" name="Username" required="" id="username" class="form-control really-simple required" />
                                    </div>
                                </div>
                                 <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="email" onautocomplete="off">Email</label></div>
                                    <div class="col-lg-12">
                                        <input type="text" name="email" required="" id="email" class="form-control email required" />
                                    </div>
                                </div>
                                   <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="Phone_Number" onautocomplete="off">Phone Number</label></div>
                                    <div class="col-lg-12">
                                        <input type="number" name="phonenumber" required="" id="email" class="form-control email required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12"><label class="control-label" for="password" onautocomplete="off">Password</label></div>
                                    <div class="col-lg-12">
                                        <input type="password" name="password" required="" id="password" class="form-control password required" />
                                    </div>
                                </div>
                                
                               
                                
                              <hr />
    
					    


					      <!-- Default inline 1-->
					      <label required>Select Gender :</label>
					     	<input type="radio" name="gender" value="female">Female
							<input type="radio" name="gender" value="male">Male
							<input type="radio" name="gender" value="other">Other
					   <div class="text-center py-4 mt-3">
				        <button class="btn btn-primary" type="submit" name="Register" value="Sign Up" >Register</button>

				        <a href="index.php?action=login" class="btn btn-info">Login</a>
				      </div>
			    </form>
    <!-- Material form register -->
               
                  </div> 
  </div>
  <!-- Card body -->

</div>
<!-- Card -->

</div>
 


	<?php

{ } } ?>









<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>






